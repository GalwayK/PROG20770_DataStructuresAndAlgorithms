// Fig. 6.22: fig06_22.c
// Double-subscripted array manipulations.
#include <stdio.h>
#define STUDENTS 3
#define EXAMS 4

// function prototypes
int minimum( int grades[][ EXAMS ], size_t pupils, size_t tests );
int maximum( int grades[][ EXAMS ], size_t pupils, size_t tests );
double average( const int setOfGrades[], size_t tests );
void printArray( int grades[][ EXAMS ], size_t pupils, size_t tests );

// function main begins program execution
int main( void )
{
   size_t student; // student counter

   // initialize student grades for three students (rows)
   int studentGrades[ STUDENTS ][ EXAMS ] =  
      { { 77, 68, 86, 73 },
        { 96, 87, 89, 78 },
        { 70, 90, 86, 81 } };

   // output array studentGrades
   puts( "The array is:" );
   printArray( studentGrades, STUDENTS, EXAMS );

   // determine smallest and largest grade values
   printf( "\n\nLowest grade: %d\nHighest grade: %d\n",
      minimum( studentGrades, STUDENTS, EXAMS ),
      maximum( studentGrades, STUDENTS, EXAMS ) );

   // calculate average grade for each student
   for ( student = 0; student < STUDENTS; ++student ) {
      printf( "The average grade for student %u is %.2f\n", 
         student, average( studentGrades[ student ], EXAMS ) );
   } // end for
} // end main

// Find the minimum grade
int minimum( int grades[][ EXAMS ], size_t pupils, size_t tests )
{
   size_t i; // student counter
   size_t j; // exam counter
   int lowGrade = 100; // initialize to highest possible grade

   // loop through rows of grades
   for ( i = 0; i < pupils; ++i ) {

      // loop through columns of grades
      for ( j = 0; j < tests; ++j ) {

         if ( grades[ i ][ j ] < lowGrade ) {
            lowGrade = grades[ i ][ j ];
         } // end if
      } // end inner for
   } // end outer for

   return lowGrade; // return minimum grade 
} // end function minimum

// Find the maximum grade
int maximum( int grades[][ EXAMS ], size_t pupils, size_t tests )
{
   size_t i; // student counter
   size_t j; // exam counter
   int highGrade = 0; // initialize to lowest possible grade

   // loop through rows of grades
   for ( i = 0; i < pupils; ++i ) {

      // loop through columns of grades
      for ( j = 0; j < tests; ++j ) {

         if ( grades[ i ][ j ] > highGrade ) {
            highGrade = grades[ i ][ j ];
         } // end if
      } // end inner for
   } // end outer for

   return highGrade; // return maximum grade
} // end function maximum

// Determine the average grade for a particular student
double average( const int setOfGrades[], size_t tests )      
{                                                         
   size_t i; // exam counter                              
   int total = 0; // sum of test grades                
                                                          
   // total all grades for one student                 
   for ( i = 0; i < tests; ++i ) {                        
      total += setOfGrades[ i ];                          
   } // end for                                        
                                                          
   return ( double ) total / tests; // average         
} // end function average                              

// Print the array
void printArray( int grades[][ EXAMS ], size_t pupils, size_t tests )
{
   size_t i; // student counter
   size_t j; // exam counter

   // output column heads
   printf( "%s", "                 [0]  [1]  [2]  [3]" );

   // output grades in tabular format
   for ( i = 0; i < pupils; ++i ) {

      // output label for row
      printf( "\nstudentGrades[%d] ", i );

      // output grades for one student
      for ( j = 0; j < tests; ++j ) {
         printf( "%-5d", grades[ i ][ j ] );
      } // end inner for
   } // end outer for
} // end function printArray

/**************************************************************************
 * (C) Copyright 1992-2013 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 *************************************************************************/

